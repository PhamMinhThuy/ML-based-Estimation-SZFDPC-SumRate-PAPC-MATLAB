function RRMSE = Cal_Metrics(X, Y, k)
nSet = size(X,2)/k;
X_n = [ones(1,nSet*k);X];
RRMSE_temp = 0;
for it = 1:k
X_test = X_n(:,(it-1)*nSet+1:it*nSet);
Y_test = Y((it-1)*nSet+1:it*nSet,:);
X_train = zeros(size(X_n,1),(k-1)*nSet);
if(it == 1)
   X_train = X_n(:,nSet+1:end);
   Y_train =Y(nSet+1:end,:) ;
else
    X_train = [X_n(:,1:(it-1)*nSet), X_n(:,it*nSet+1:end)];
    Y_train = [Y(1:(it-1)*nSet,:);Y(it*nSet+1:end,:)];
end
%find the estimator
W1 = linear_ls(X_train,Y_train);%linear OLS
Y_est = zeros(k,size(Y_train,2));
for iter = 1:nSet
x = X_test(:,iter);
Y_est(iter,:) = W1'*x;
end
%calculate the metric
n_samples = size(Y_test,1);
RRMSE_temp = RRMSE_temp + norm(Y_est-Y_test)/(sqrt(n_samples)*mean(Y_test));
end
%average the results
RRMSE = RRMSE_temp/k;
end

function W = linear_ls(X,y)
W = pinv(X*X')*X*y;
end

function W = linear_ridge_ls(X,y, a)
W = inv(X*X' + a*eye(size(X,1)))*X*y;
end
