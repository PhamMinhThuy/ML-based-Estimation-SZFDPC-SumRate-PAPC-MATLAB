%%
%
%Created on April 2019
%Updated on July 2019
%@author: T. M. Pham, R. Farrell, and L.-N. Tran
%Related publication: T. M. Pham, R. Farrell, and L.-N. Tran,
%�On estimating maximum sum rate of MIMO systems with successive zero-
%forcing dirty paper coding and per-antenna power constraint,�
%in Proc. IEEE PIMRC, Sep. 2019
%The data generated from the optimal solution
%The result is only for OLS


clear all;
%number of receive antennas
nr = 2;
%number of users
numuser = 2;
fold = 10;
nt_Set = 32:8:64;
RRMSE = zeros(size(nt_Set,2),1);
RRMSE_new = zeros(size(nt_Set,2),1);

for k = 1: size(nt_Set,2)
    nt = nt_Set(k);%number of transmit antennas
    file1 = sprintf('MUMIMO_%sx%s_NUsers_%s',num2str(nt),num2str(nr),num2str(numuser));
    load(file1,'X', 'Y');
    
    %without feature design
    RRMSE(k) = Cal_Metrics(X(2:end,:), Y, fold);
    
    %with feature design
    index = feature_selection_PCA(X(2:end,:),nt + numuser*min(nt,nr));
    X_test = X(1+index,:);
    Ang= angle(X_test);
    ind_Ang = find(Ang == 0);
    X_test = log(abs(X_test));
    RRMSE_new(k) = Cal_Metrics(X_test, Y, fold);
end

%plot the comparison
figure()
semilogy(nt_Set,RRMSE,'--b',nt_Set,RRMSE_new,'-k','LineWidth',1.1);
legend('Raw-data, without FD', 'Processed-data, with FD','Location','Best');
xlabel('Number of transmit antennas, N','FontSize',12,'FontWeight','bold');
ylabel('aRRMSE','FontSize',12,'FontWeight','bold');
